CREATE DATABASE ASSIGNMENT1

USE ASSIGNMENT1

SELECT * FROM Users
SELECT * FROM Posts
SELECT * FROM Friends
SELECT * FROM PagesLikes
SELECT * FROM Pages
SELECT * FROM PostLikes
SELECT * FROM Photos
SELECT * FROM Shares
SELECT * FROM Comments
SELECT * FROM CommentLikes

DROP TABLE Users
DROP TABLE Posts
DROP TABLE Friends
DROP TABLE PagesLikes
DROP TABLE Pages
DROP TABLE PostLikes
DROP TABLE Photos
DROP TABLE Shares
DROP TABLE Comments
DROP TABLE CommentLikes

CREATE TABLE Users(
	UserId CHAR(7),
	FirstName VARCHAR(100),
	LastName VARCHAR(100),
	School VARCHAR(255),
	Address VARCHAR(255),
	Email VARCHAR(255),
	PhoneNumber VARCHAR(30),
	Location VARCHAR(255),
	DateOfBirth DATE,
	Gender VARCHAR(20),
	PRIMARY KEY(UserId)
)

CREATE TABLE Posts(
	PostId CHAR(7),
	UserId CHAR(7),
	PostDate DATE,
	PostContent VARCHAR(255),
	PRIMARY KEY(PostId,UserId),
	CONSTRAINT PostsUserIdFK FOREIGN KEY(UserId) REFERENCES Users(UserId)
)

CREATE TABLE PostLikes(
	UserId CHAR(7),
	PostId CHAR(7),
	Qty INT,
	CONSTRAINT PostLikesPostIdFK FOREIGN KEY(PostId) REFERENCES Posts(PostId),
	CONSTRAINT PostLikesPostIdFK FOREIGN KEY(PostId) REFERENCES Posts(PostId)
	PRIMARY KEY(PostId,UserId)
)

CREATE TABLE Photos(
	PostId CHAR(7),
	PhotoId CHAR(8),
	ImageContent VARCHAR(255),
	CONSTRAINT PhotosPostIdFK FOREIGN KEY(PostId) REFERENCES Posts(PostId),
	CONSTRAINT PhotosPhotoIdPK PRIMARY KEY(PhotoId)
)

CREATE TABLE Shares(
	UserId CHAR(7),
	PostId CHAR(7),
	Qty INT,
	CONSTRAINT SharesPostIdFK FOREIGN KEY(PostId) REFERENCES Posts(PostId),
	CONSTRAINT SharesUserIdFK FOREIGN KEY(UserId) REFERENCES Posts(UserId)
)

CREATE TABLE Comments(
	UserId CHAR(7),
	PostId CHAR(7),
	CommentId CHAR(10),
	CommentDate DATE,
	CommentContent VARCHAR(255),
	PRIMARY KEY(UserId,CommentId),
	CONSTRAINT CommentsUserIdFK PRIMARY KEY(UserId),
	CONSTRAINT CommentsPostIdFK FOREIGN KEY(PostId) REFERENCES Posts(PostId),
	CONSTRAINT CommentsCommentIdPK PRIMARY KEY(CommentId)
)

CREATE TABLE CommentLikes(
	UserId CHAR(7),
	CommentId CHAR(10),
	Qty INT,
	CONSTRAINT CommentLikesUserIdFK FOREIGN KEY(UserId) REFERENCES Comments(UserId),
	CONSTRAINT CommentLikesCommentIdFK FOREIGN KEY(CommentId) REFERENCES Comments(CommentId),
)

CREATE TABLE Friends(
	UserId CHAR(7),
	FriendId CHAR(9),
	PRIMARY KEY(FriendId,UserId),
	CONSTRAINT FriendsUserIdFK FOREIGN KEY(UserId) REFERENCES Users(UserId),
)

CREATE TABLE PagesLikes(
	UserId CHAR(7),
	PageId CHAR(7),
	PRIMARY KEY(UserId,PageId),
	CONSTRAINT PagesLikesUserIdFK FOREIGN KEY(UserId) REFERENCES Users(UserId),
	CONSTRAINT PagesLikesPageIdFK FOREIGN KEY(PageId) REFERENCES Pages(PageId),
)

CREATE TABLE Pages(
	PageId CHAR(7),
	PageName VARCHAR(255),
	PageContent VARCHAR(255),
	CONSTRAINT PagesPageIdPK PRIMARY KEY(PageId),
)

